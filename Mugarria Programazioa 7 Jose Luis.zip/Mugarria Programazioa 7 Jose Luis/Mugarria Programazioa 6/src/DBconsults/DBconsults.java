package DBconsults;

import DBconection.DBconection;
import model.Photographer;
import model.Picture;

import javax.swing.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class DBconsults {
    private Connection conection;

    public DBconsults(Connection connection) {
        this.conection = connection;
    }

    /*
    este metodo devuelve una List de Strings la lista de String esta llena de nombres de fotografos, que conseguimos de la consulta
    select name from photograhpher
    */

    public List<String> LoadPhotographers() {
        List<String> photographerNames = new ArrayList<>();
        ResultSet result = null;
        String query = "SELECT name FROM Photographer";
        try (PreparedStatement st = conection.prepareStatement(query)) {
            result = st.executeQuery();
            while (result.next()) {
                photographerNames.add(result.getString("name"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return photographerNames;
    }

    /*
    Este metodo devuelve una lista de pictures, al selecionar toda la imagen tenemos que añadir todas y cada una de las columnas
    */
    public List<Picture> getPicturesByPhotographer(String photographerName) {
        List<Picture> pictures = new ArrayList<>();
        ResultSet result = null;
        String query = "SELECT * FROM Picture WHERE photographerId = ?";
        try (PreparedStatement st = conection.prepareStatement(query)) {

            st.setInt(1, getPhotographerId(photographerName));
            // System.out.println("DEBUG: PHOTOGRAPHER ID"+ getPhotographerId(photographerName));
            result = st.executeQuery();

            while (result.next()) {
                int pictureId = result.getInt("pictureId");
                String title = result.getString("title");
                Date date_ = result.getDate("date");
                String file = result.getString("file");
                int visits = result.getInt("visits");
                int photographerId = result.getInt("photographerId");

                pictures.add(new Picture(pictureId, title, date_, file, visits, photographerId));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return pictures;
    }

    /*
    Este metodo devuelve una lista de pictures, al selecionar toda la imagen tenemos que añadir todas y cada una de las columnas, en este caso el resultado esta
    limitado por la fecha de datepicker y el id del fotografo
    */
    public List<Picture> getPicturesByPhotographerAndDate(String photographerName, String date) {
        List<Picture> pictures = new ArrayList<>();
        ResultSet result = null;
        String query = "SELECT * FROM Picture WHERE photographerId = ? AND date > ?";
        try (PreparedStatement st = conection.prepareStatement(query)) {
            st.setInt(1, getPhotographerId(photographerName));
            st.setString(2, date);
            result = st.executeQuery();

            while (result.next()) {
                int pictureId = result.getInt("pictureId");
                String title = result.getString("title");
                Date date_ = result.getDate("date");
                String file = result.getString("file");
                int visits = result.getInt("visits");
                int photographerId = result.getInt("photographerId");


                pictures.add(new Picture(pictureId, title, date_, file, visits, photographerId));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return pictures;
    }

    /*
    metodo que devuelve int  recibe una String (el nombre de un fotografo) este lo utiliza despues para sustituirlo en la consulta, con este metodo conseguimos el
    id del fotografo utilizando su nombre
    */
    public int getPhotographerId(String photographerName) {
        int photographerId = 0;
        ResultSet result = null;
        String query = "SELECT photographerId FROM Photographer WHERE name = ?";
        try (PreparedStatement st = conection.prepareStatement(query)) {
            st.setString(1, photographerName);
            result = st.executeQuery();

            if (result.next()) {
                photographerId = result.getInt("photographerId");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return photographerId;
    }

    /*
    este metodo void accede a la tabla picture y updatea el apartado visits sumandole 1, a este metodo se accede clickando dos veces en el titulo de la foto, esta en WINDOW
     */
    public void updateVisits(int pictureId) {
        String query = "UPDATE Picture SET visits=(visits+1) WHERE pictureId = ?";
        try (PreparedStatement st = conection.prepareStatement(query)) {
            st.setInt(1, pictureId);
            int updated = st.executeUpdate();
            System.out.println(updated + " sucessfully updated");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    /*
    Este metodo crea un hashmap que se compone de dos integer el valor del id del fotografo y la suma total de
    las fotos que tengan su id
    ademas imprimimos en la consola su contenido para que sea mas facil la correccion del metodo award!!
     */
    public HashMap<Integer, Integer> createVisits() {
        String query = "Select photographerId, sum(visits) from picture group by photographerId";
        HashMap<Integer, Integer> visitsMap = new HashMap<>();
        try (PreparedStatement st = conection.prepareStatement(query)) {
            ResultSet result = st.executeQuery();
            while (result.next()) {
                int photographerId = result.getInt(1);
                int numberOfVisits = result.getInt(2);
                System.out.println(photographerId + " id_photographer" + " visits = " + numberOfVisits);
                visitsMap.put(photographerId, numberOfVisits);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return visitsMap;
    }

    /*
    Este metodo revisa que el fotografo que esta analizando cumpla el requisito de visitas que se pregunta en el joption
    en el caso de que si updateara la columna sino lo dejara igual, es importante recalcar que lo hace en base al hashmap que nos
    crea el metodo createVisits. una vez lo recorre comprueba que el numero de visitas sea mayor o igual al que pedimos en la ventana
    los fotografos que cumplan el requisito se actualizaran mientras los que no no.
     */
    public void awardPhotographer() {
            int minimumVisits = 0;
            String query = "UPDATE photographer SET awarded = 1 WHERE photographerId = ?";
            DBconsults dBconsults = new DBconsults(DBconection.getConnection());
            HashMap<Integer, Integer> visitsMap = dBconsults.createVisits();
            minimumVisits = Integer.valueOf(JOptionPane.showInputDialog("Minimum number of visits to get a prize"));

            for (Map.Entry<Integer, Integer> entry : visitsMap.entrySet()) {
                int key = entry.getKey();
                int value = entry.getValue();
                if (value >= minimumVisits) {
                    try (PreparedStatement st = conection.prepareStatement(query)) {
                        st.setInt(1, key);
                        st.executeUpdate();
                        System.out.println("Executing update for photographerId: " + key);
                    } catch (SQLException e) {
                        throw new RuntimeException(e);
                    }
                } else {
                    System.out.println("PhotographerId: " + key + " doesn't meet the requirements");
                }
            }
        }
        public List<Picture> listUnviewPictures(){
        List<Picture> unviewedPictures= new ArrayList<>();
        String query ="Select * from picture p inner join photographer ph on p.photographerId = ph.photographerId  where visits=0 and ph.awarded=0";
        try(PreparedStatement st = conection.prepareStatement(query)){
            ResultSet result= st.executeQuery();
            while (result.next()){
                int pictureId = result.getInt("pictureId");
                String title = result.getString("title");
                Date date_ = result.getDate("date");
                String file = result.getString("file");
                int visits = result.getInt("visits");
                int photographerId = result.getInt("photographerId");
                unviewedPictures.add(new Picture(pictureId, title, date_, file, visits, photographerId));
            }
        }catch (SQLException e){
            throw new RuntimeException(e);
        }
        return unviewedPictures;
        }

        public void deletePicture(int id_picture){
        String query="Delete from picture where pictureId =?";
        try(PreparedStatement st= conection.prepareStatement(query)){
            st.setInt(1,id_picture);
            int rowsAffected = st.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Picture deleted. ");
            } else {
                System.out.println("No picture found with the ID.");
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }

    }
}

