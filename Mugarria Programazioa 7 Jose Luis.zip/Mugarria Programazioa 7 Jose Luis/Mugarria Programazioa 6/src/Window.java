
import DBconection.DBconection;
import DBconsults.DBconsults;
import model.Picture;
import org.jdesktop.swingx.JXDatePicker;

import javax.swing.*;
import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Window extends JFrame {
    private JComboBox<String> photographerComboBox;
    private JXDatePicker datePicker;
    private JList<String> pictureList;
    private ImageIcon pictureImage;
    private  JLabel imageLabel;
    List<Picture> pictures;
    private JButton award,remove;
    private JPanel buttonsPanel;


    public Window(){
        setTitle("Photography");
        setLayout(new GridLayout(4,1));
        setPreferredSize(new Dimension(800, 600));
        this.pack();

        setLocationRelativeTo(null);

        setDefaultCloseOperation(EXIT_ON_CLOSE);
        photographerComboBox = new JComboBox<>();
        datePicker = new JXDatePicker();
        pictureList = new JList<>();
        imageLabel = new JLabel();
        award=new JButton("AWARD");
        remove= new JButton("REMOVE");




        JPanel photographerPanel = new JPanel();
        photographerComboBox.setPreferredSize(new Dimension(200,40));
        photographerComboBox.addItem(null);
        photographerComboBox.addActionListener(e -> loadPictureList((String) photographerComboBox.getSelectedItem()));
        this.loadPhotographersComboBox();

        photographerPanel.add(new JLabel("Photographer: "));
        photographerPanel.add(photographerComboBox);


        JPanel datePanel = new JPanel();
        datePanel.add(new JLabel("Photos after: "));
        datePicker.addActionListener(e -> loadPictureList((String) photographerComboBox.getSelectedItem()));
        datePanel.add(datePicker);


        JScrollPane pictureScrollPanel = new JScrollPane(pictureList);
        pictureScrollPanel.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        pictureList.addMouseListener(new MouseAdapter() {


            /*
        este es el apartado de codigo que utiliza el metodo updatevisit.
        */
            @Override
            public void mouseClicked(MouseEvent e) {
                if(e.getClickCount() ==  2){
                    for(Picture p: pictures){
                        if(pictureList.getSelectedValue().equals(p.getTitle())){
                            loadPictureImage(p.getFile());
                            new DBconsults(DBconection.getConnection()).updateVisits(p.getPictureId());
                        }
                    }
                }
            }
        });
        award.addActionListener(e -> {
            DBconsults dBconsults= new DBconsults(DBconection.getConnection());
            dBconsults.awardPhotographer();

        });
        remove.addActionListener(e -> {
            DBconsults dBconsults= new DBconsults(DBconection.getConnection());
            unviewedPhotosDeleteOption();
        });


        JPanel picturePanel = new JPanel();
        picturePanel.add(imageLabel);
        buttonsPanel=new JPanel();
        buttonsPanel.setLayout(new FlowLayout());


        add(photographerPanel);
        add(datePanel);
        add(pictureScrollPanel);
        add(picturePanel);
        buttonsPanel.add(award);
        buttonsPanel.add(remove);
        add(buttonsPanel);
        pack();
        setVisible(true);
    }
    /*
    Metodo para cargar el combobox de fotografos, utiliza el metodod loadphotographers de la clase DBconsults
     */
    private void loadPhotographersComboBox(){
        DBconsults consults = new DBconsults(DBconection.getConnection());
        List<String> photographerNames = consults.LoadPhotographers();

        for (String p: photographerNames){
            photographerComboBox.addItem(p);
        }
    }
    
    private void loadPictureList(String photographerName){
        DBconsults consults = new DBconsults(DBconection.getConnection());

        DefaultListModel<String> pictureTitles = new DefaultListModel<>();

        if(datePicker.getDate() != null){
            SimpleDateFormat formatDate = new SimpleDateFormat("yyyy-MM-dd");
            String newDate = formatDate.format(datePicker.getDate());

            pictures = consults.getPicturesByPhotographerAndDate(photographerName, newDate);
        }else{
            System.out.println(consults.getPicturesByPhotographer(photographerName));
            pictures = consults.getPicturesByPhotographer(photographerName);
        }

        for (Picture p: pictures){
            pictureTitles.addElement(p.getTitle());
        }
        this.pictureList.setModel(pictureTitles);
    }
    /*
    metodo para cargar la imagen recibe como String picture/File de la base de datos, en la columna file esta la ruta completa
    (Mugarria programazioa 6/src/images/"nombre de la foto")
     */
    private void loadPictureImage(String imagePath){
        pictureImage = new ImageIcon(imagePath);
        Image image = pictureImage.getImage().getScaledInstance(250,250,Image.SCALE_SMOOTH);
        pictureImage = new ImageIcon(image);
        imageLabel.setIcon(pictureImage);
    }
    /*
    Este metodo recorre un List que recibe desde el metodo UnviewPictures en la clase DBconsults, este List esta lleno de Picture que cumplen
    la condicion de no tener visitas y de que su fotografo no este premiado, en cada vuelta del for pregunta al usuario en un Joption pane si quiere eliminarla
    en el caso de que la option sea YES se utiliza un metodo que recibe la id de la imagen y hace un delete en la base;
     */

    public void unviewedPhotosDeleteOption(){
        DBconsults dBconsults=new DBconsults(DBconection.getConnection());
        List<Picture>listUnviewPictures= dBconsults.listUnviewPictures();

        for (int i = 0; i<listUnviewPictures.size();i++){
            Picture picture = listUnviewPictures.get(i);
            int response = JOptionPane.showConfirmDialog(null, "Do u want delete the picture: "+picture.getPictureId(),picture.getTitle(),JOptionPane.YES_NO_OPTION);
            if(response== JOptionPane.YES_OPTION){
                dBconsults.deletePicture(picture.getPictureId());
            }else if(response== JOptionPane.NO_OPTION){
                JOptionPane.showInputDialog("The picture has been not deleted");
            }else{
                System.out.println("the user close the window");
            }
        }
    }

    public static void main(String[] args) {
        new Window();

    }
}
